CREATE DATABASE recruitment_system;
USE recruitment_system;
CREATE TABLE Candidate (
    candidate_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15) UNIQUE,
    skills VARCHAR(255)
);
CREATE TABLE Job_Post 
(
    job_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(100) NOT NULL,
    department VARCHAR(100),
    salary_range VARCHAR(50)
);
CREATE TABLE Application 
(
    app_id INT PRIMARY KEY AUTO_INCREMENT,
    candidate_id INT,
    job_id INT,
    apply_date DATE,
    status VARCHAR(50) CHECK (status IN ('Applied','Interview','Selected','Rejected')),
	FOREIGN KEY (candidate_id) REFERENCES Candidate(candidate_id),
    FOREIGN KEY (job_id) REFERENCES Job_Post(job_id)
);
INSERT INTO Candidate (name, email, phone, skills)
VALUES ('Ali Khan', 'ali@gmail.com', '03001234567', 'SQL, Java'),
       ('Sara Ahmed', 'sara@gmail.com', '03111234567', 'Python, AI');
INSERT INTO Job_Post (title, department, salary_range)
VALUES ('Software Engineer', 'IT', '80k-120k'),
       ('Data Analyst', 'Data Science', '70k-110k');
INSERT INTO Application (candidate_id, job_id, apply_date, status)
VALUES (1, 1, '2026-05-01', 'Applied'),
       (1, 2, '2026-05-02', 'Interview'),
       (2, 2, '2026-05-03', 'Selected');
CREATE VIEW application_summary AS
SELECT c.name, j.title, a.status
FROM Application a
JOIN Candidate c ON a.candidate_id = c.candidate_id
JOIN Job_Post j ON a.job_id = j.job_id;
SELECT c.name, j.title, a.status
FROM Application a
JOIN Candidate c ON a.candidate_id = c.candidate_id
JOIN Job_Post j ON a.job_id = j.job_id;
SELECT name
FROM Candidate
WHERE candidate_id IN (
    SELECT candidate_id
    FROM Application
    WHERE status = 'Selected'
);
SELECT j.title, COUNT(a.app_id) AS total_applicants
FROM Job_Post j
LEFT JOIN Application a ON j.job_id = a.job_id
GROUP BY j.title;
SELECT * FROM Candidate
WHERE skills LIKE '%SQL%';
SELECT status, COUNT(*) AS total
FROM Application
GROUP BY status;